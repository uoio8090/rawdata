# 메르세데스-벤츠 C-클래스 성능테스트

## 성능 시험 결과

| 발행처 | Model year | 트림 | Metric | 값 | Unit | 시험조건 | Source |
|---|---|---|---|---|---|---|---|
| Car and Driver(검색 결과 요약 인용) | 2022 | C 300 | 0-60 mph | 5.3 | s | 미국 시험; 2차 인용 | https://www.motormatchup.com/catalog/Mercedes_Benz/C_Class/2023/C-300-4MATIC-Sedan |

---
※ 교육 실습용으로 공개된 수치를 재구성한 자료입니다. 실제 의사결정에 사용하지 마세요.