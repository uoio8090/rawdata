# BYD 씰 모델분석

## 모델 분석

| 연식 | 요약 | 출처 |
|---|---|---|
| 2023 | BYD의 e-Platform 3.0 기반 중형 전기 세단으로 블레이드 LFP 배터리를 쓴다. RWD 단일모터와 AWD 듀얼모터(0-100km/h 3.8초) 구성이며 Euro NCAP 5성을 받았다. 2023년 중국에서 가격을 낮춘 Champion Edition이 나왔고 해외 시장 판매가 시작됐다. (2차 출처 요약) | https://en.wikipedia.org/wiki/BYD_Seal |
| 2024 | 3월 Honor Edition으로 약 5% 가격 인하, 8월에는 라이다 추가와 외관·실내 변경이 있는 중국 페이스리프트가 나왔다. (2차 출처 요약) | https://en.wikipedia.org/wiki/BYD_Seal |
| 2025 | 동남아에서 라인업 조정이 이어졌다. 말레이시아는 휠과 어댑티브 댐퍼를 바꾸고 Dynamic RWD를 뺐으며, ASEAN NCAP 5성을 받았다. (2차 출처 요약) | https://en.wikipedia.org/wiki/BYD_Seal |

## 연식별 변경

| 연식 | 트림 | 엔진/배터리 | 출력 | 구동 | 연비/전비 | 주행거리(km) | 측정기준 | 0-100km/h(초) | 가격 | 통화 | 변경사항 | 출처 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2023 | Standard Range (RWD) | 61.44 kWh LFP Blade | 150 kW / 310 N·m | RWD | 해당없음 | 460 | WLTP (CLTC 550 / NEDC 510) | 7.5 | 해당없음 | 해당없음 | 2023년 5월 중국 Champion Edition 출시, 가격 인하. 2023년 하반기 유럽·태국·브라질 등 판매 개시. | https://en.wikipedia.org/wiki/BYD_Seal |
| 2023 | Prestige 700km (중국 전용) | 82.56 kWh LFP Blade | 170 kW / 330 N·m | RWD | 해당없음 | 700 | CLTC | 해당없음 | 해당없음 | 해당없음 | Champion Edition과 함께 추가(2023-2026 중국). | https://en.wikipedia.org/wiki/BYD_Seal |
| 2024 | 전 트림(중국 Honor Edition) | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 2024년 3월 Honor Edition으로 가격 약 5% 인하. 2024년 8월 중국 페이스리프트: 새 휠, RoboSense LiDAR, 실내 변경. 트림별 2024 제원은 미확인. | https://en.wikipedia.org/wiki/BYD_Seal |
| 2025 | 말레이시아 라인업 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 해당없음 | 2025년 8월 말레이시아에서 새 휠·어댑티브 댐퍼 적용, Dynamic RWD 단종. 필리핀은 1월 Advanced RWD 추가. 트림별 2025 제원은 미확인. | https://en.wikipedia.org/wiki/BYD_Seal |

---
※ 교육 실습용으로 공개된 수치를 재구성한 자료입니다. 실제 의사결정에 사용하지 마세요.