# 메르세데스-벤츠 재무

## 재무 요약

| 기간 | Basis | 통화 | Unit | 매출액 | Operating income | 당기순이익 | Total assets | 부채총계 | Total equity | 출처 |
|---|---|---|---|---|---|---|---|---|---|---|
| FY2024 | 연결 | EUR | 백만유로 | 145594 | 13599 | 10410 | N/A | N/A | 93630 | https://www.marklines.com/en/news/322318 |
| FY2023 | 연결 | EUR | 백만유로 | 152390 | 19660 | 14530 | N/A | N/A | N/A | https://www.marklines.com/en/news/322318 |
| FY2022 | 연결 | EUR | 백만유로 | 150000 | N/A | 14500 | 260000 | N/A | N/A | https://en.wikipedia.org/wiki/Mercedes-Benz_Group |

---
※ 교육 실습용으로 공개된 수치를 재구성한 자료입니다. 실제 의사결정에 사용하지 마세요.