# BYD 재무

## 재무 요약

| 기간 | Basis | 통화 | Unit | 매출액 | Operating income | 당기순이익 | Total assets | 부채총계 | Total equity | 출처 |
|---|---|---|---|---|---|---|---|---|---|---|
| FY2023 | consolidated | RMB | billion | 602.3 |  | 30.04 |  |  |  | https://equalocean.com/news/2024032720688-byd-releases-2023-financial-report-net-profit-up-80-year-year |
| FY2024 | consolidated | RMB | billion | 777.102 |  | 40.254 |  |  |  | https://autonews.gasgoo.com/articles/ev/70036461 |

---
※ 교육 실습용으로 공개된 수치를 재구성한 자료입니다. 실제 의사결정에 사용하지 마세요.