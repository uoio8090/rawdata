# 도요타자동차 bZ4X 차량보고서

## 제원

| 연식 | Trim | 엔진/배터리 | Power | 구동 | Fuel economy/Efficiency | 주행거리(km) | Range std | 0-100km/h(초) | Price | 통화 | Changes | 출처 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2023 | XLE FWD (북미) | 71.4 kWh | 150 kW (201 hp) 단일 모터 | FWD | N/A | 406 | EPA 252 mi | 7.5 | N/A | USD | 북미 최초 판매 연식. 0-100은 2021 제조사 발표치 | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| 2023 | XLE AWD (북미) | 72.8 kWh | 합산 160 kW (215 hp) 듀얼 모터 | AWD | N/A | 367 | EPA 228 mi | 6.9 | N/A | USD | N/A | https://insideevs.com/news/664971/2023-toyota-bz4x-price-epa-range/ |
| 2023 | Limited AWD 20인치 (북미) | 72.8 kWh | 합산 160 kW (215 hp) 듀얼 모터 | AWD | N/A | 357 | EPA 222 mi | 6.9 | N/A | USD | N/A | https://insideevs.com/news/664971/2023-toyota-bz4x-price-epa-range/ |
| 2023 | 유럽 (참고) | 71.4 kWh | N/A | FWD/AWD | N/A | N/A | WLTP 460-530 km | N/A | N/A | N/A | N/A | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| 2024 | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | 2024 단독 제원 미확인(2022-2025 FWD 71.4 kWh 팩 유지로만 기재됨) | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| 2025 | XLE FWD (북미) | 71.4 kWh | N/A | FWD | N/A | N/A | EPA 252 mi (보도 기준) | N/A | 37070 | USD | 2024 대비 대폭 가격 인하(XLE 약 6천달러), Nightshade 트림 추가. 가격은 목적지 수수료 $1,395 제외 MSRP(포함 시 $38,465) | https://www.greencarreports.com/news/1145302_2025-toyota-bz4x-price |
| 2025 | XLE AWD (북미) | 72.8 kWh | N/A | AWD | N/A | N/A | EPA 228 mi | N/A | 39150 | USD | 수수료 포함가 $40,545에서 $1,395를 뺀 파생값 | https://www.cars.com/articles/toyota-drops-bz4x-price-almost-6000-adds-nightshade-trim-502801 |
| 2025 | Limited FWD / Limited AWD (북미) | N/A | N/A | FWD/AWD | N/A | N/A | EPA 236 mi (FWD) / 222 mi (AWD) | N/A | N/A | USD | 수수료 포함가 Limited FWD $43,195, AWD $45,275, Nightshade AWD $41,815; Limited 약 $5,380 인하 | https://www.cars.com/articles/toyota-drops-bz4x-price-almost-6000-adds-nightshade-trim-502801 |

## 안전성

| 기관 | Year | 연식 | Rating | 출처 |
|---|---|---|---|---|
| IIHS | 2025 | 2025 (2024년 12월 이후 생산분) | Top Safety Pick+ ; 소형 중첩 Good(2023-25), 중간 중첩 Good(2024-25), 측면 Good(2023-25, 2022.10 이후 생산), 보행자 전방충돌방지 Good(2024-25), 헤드램프 Limited Good / XLE 2025.1 이후 Good, XLE 2025.1 이전 Marginal | https://www.iihs.org/ratings/vehicle/toyota/bz4x-4-door-suv/2025 |
| Euro NCAP | 2022 | 2022 평가 | 5성 (성인 88%, 아동 87%, 보행자 79%, 안전보조 91%) | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| Euro NCAP | 2025 | 2025 평가 | 5성 (성인 88%, 아동 85%, 보행자 80%, 안전보조 79%) | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| NHTSA | N/A | 2023 | 전체 5성(2차 취합 사이트 보도, NHTSA 원문 미확인) | https://www.autoblog.com/buy/2023-Toyota-bZ4X/recalls/ |

## 리콜

| 연도 | Model year | 내용 | Source |
|---|---|---|---|
| 2022 | 2023 | NHTSA 22V-444. 허브 볼트가 풀려 저주행 후 휠 이탈 가능. 미국 약 260대(bZ4X 2023형), 솔테라 403대 별도. 2022.10 개선 볼트(와셔 포함)·개선 휠로 수리 확정 | https://static.nhtsa.gov/odi/rcl/2022/RCMN-22V444-6442.pdf |
| 2022 | 2022-2023 (글로벌) | 휠 이탈 우려로 bZ4X 약 2,700대, 솔테라 약 2,600대 리콜, 생산·판매 중단 후 10월 재개 | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| 2025 | 2023-2025 | NHTSA 25V-577. HVAC 계통 고장 시 디프로스터 기능 저하(시야 확보 문제). bZ4X, 렉서스 RZ, 솔테라 대상 | https://www.cars.com/research/toyota-bz4x-2024/recalls/ |
| 2025 | 2024 | NHTSA 25V-744. 후방 영상/백오버 방지 표시 기능 관련(파노라믹 뷰 모니터·주차보조 ECU 소프트웨어). 리콜일 2025-10-29 | https://www.cars.com/recalls/toyota-bz4x-2024/ |

## 판매량

| 기간 | Scope | 판매량 | Source |
|---|---|---|---|
| 2023 (CY) | bZ4X 미국 | 9329 | https://insideevs.com/news/747286/toyota-bz4x-sales-success-2024/ |
| 2024 (CY) | bZ4X 미국 | 18570 | https://insideevs.com/news/747286/toyota-bz4x-sales-success-2024/ |
| 2025 (CY) | bZ4X 미국 | 15609 | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| 2023 (CY) | bZ4X 유럽 | 19606 | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| 2024 (CY) | bZ4X 유럽 | 24465 | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| 2025 (CY) | bZ4X 유럽 | 27191 | https://en.wikipedia.org/wiki/Toyota_bZ4X |
| 2025 (CY) | 도요타·렉서스 BEV 글로벌 | 199137 | https://www.just-auto.com/newsletters/toyotas-global-vehicle-sales-rise-3-in-december |

---
※ 교육 실습용으로 공개된 수치를 재구성한 자료입니다. 실제 의사결정에 사용하지 마세요.