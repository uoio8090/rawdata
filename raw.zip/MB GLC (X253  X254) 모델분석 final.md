# 메르세데스-벤츠 GLC 모델분석

## 모델 분석

| 연식 | 요약 | 출처 |
|---|---|---|
| 2021 | X253 페이스리프트 후기 연식으로 MBUX와 신규 엔진, 12.3인치 계기판을 갖췄다. 유럽 7.5만 대 수준으로 팔렸다. | https://en.wikipedia.org/wiki/Mercedes-Benz_GLC-Class |
| 2022 | X253 마지막 연식으로 미국 판매는 6.5만 대로 늘었다. | https://en.wikipedia.org/wiki/Mercedes-Benz_GLC-Class |
| 2023 | 신세대로 교체되는 해이며 자료는 판매량 위주로만 확인했다. | https://en.wikipedia.org/wiki/Mercedes-Benz_GLC-Class |

## 연식별 변경

| 연식 | 트림 | 엔진/배터리 | 출력 | 구동 | 연비/전비 | 주행거리(km) | 측정기준 | 0-100km/h(초) | 가격 | 통화 | 변경사항 | 출처 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2021 | GLC 300 4MATIC (유럽) | 2.0L 터보 가솔린 | 190 kW (258 PS) | AWD |  |  |  | 6.2 |  |  | 2019~2020 페이스리프트 사양(MBUX, 12.3인치 디지털 계기판) | https://en.wikipedia.org/wiki/Mercedes-Benz_GLC-Class |
| 2023 |  |  |  |  |  |  |  |  |  |  | 2023년형은 신세대 X254로 전환(세부 제원 미확인) | https://en.wikipedia.org/wiki/Mercedes-Benz_GLC-Class |

---
※ 교육 실습용으로 공개된 수치를 재구성한 자료입니다. 실제 의사결정에 사용하지 마세요.