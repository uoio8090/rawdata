# 도요타자동차 bZ4X 성능테스트

## Performance test results

| Publisher | Model year | Trim | Metric | Value | Unit | Conditions | Source |
|---|---|---|---|---|---|---|---|
| Edmunds | 2023 | Limited FWD | 실주행 거리(real-world range) | 227 | miles | Edmunds 자체 실주행 루트 시험, EPA 추정치보다 15마일 부족(2차 요약 기준) | https://www.edmunds.com/car-news/tested-2023-toyota-bz4x-returns-underwhelming-real-world-range.html |
| Car and Driver (Motor Biscuit 인용) | 2023 | - | 고속도로 실주행 거리 | 160 | miles | 2차 인용, 시험 속도 미확인 | https://www.motorbiscuit.com/2023-toyota-bz4x-falls-short-range-power |
| Edmunds | 2026 | bZ (개정형) | 실주행 거리의 EPA 초과분 | 17 | miles | 요청 연식 밖 참고용(2026형) | https://www.edmunds.com/car-news/2026-toyota-bz-range-tested.html |

---
* Reconstructed from public figures for training use only.