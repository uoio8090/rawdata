# 기아 EV6 성능테스트

## Performance test results

| Publisher | Model year | Trim | Metric | Value | Unit | Conditions | Source |
|---|---|---|---|---|---|---|---|
| InsideEVs | 2022 | Long Range AWD 77.4kWh | 70mph 실측 주행거리 | 254 | miles | 70 mph 일정속도 주행 시험 | https://insideevs.com/news/576754/kia-ev6-awd-70mph-range/ |
| Consumer Reports | 2025 | AWD | 70mph 고속도로 주행거리 | 277 | miles | EPA 282 mi 대비; 2025년형이라 대상 연식 밖 | https://www.consumerreports.org/cars/kia/ev6/2025/road-test-report/ |
| Edmunds | 2025 | GT-Line AWD | 0-60 mph | 4.9 | s | 계측 시험; 2025년형이라 대상 연식 밖 | https://edmunds.com/car-news/2025-kia-ev6-gt-line-tested.html |
| Edmunds | 2025 | GT-Line AWD | 60-0 mph 제동거리 | 123 | ft | 계측 시험; 2025년형이라 대상 연식 밖 | https://edmunds.com/car-news/2025-kia-ev6-gt-line-tested.html |

---
* Reconstructed from public figures for training use only.