# 폭스바겐 ID.4 모델분석

## 모델 분석

| 연식 | 요약 | 출처 |
|---|---|---|
| 2023 | The 2023 model year brought US-built ID.4s in 62 and 82 kWh versions, with the larger pack and single motor giving the longest rated range of the lineup. Pricing started in the high 30s thousand USD and reached the low 50s for AWD Pro S. | https://insideevs.com/news/664846/2023-volkswagen-id4-epa-range-prices/ |
| 2024 | For 2024 the single-motor 82 kWh versions gained a stronger, more efficient drive unit, lifting EPA range to 291 miles. Pro trims also got a larger 12.9-inch screen with reworked software, and prices rose slightly. | https://insideevs.com/news/710357/2024-volkswagen-id4-prices/ |

## 연식별 변경

| 연식 | 트림 | 엔진/배터리 | 출력 | 구동 | 연비/전비 | 주행거리(km) | 측정기준 | 0-100km/h(초) | 가격 | 통화 | 변경사항 | 출처 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2023 | Pro S 20-inch RWD | 82 kWh | 150 kW | RWD | 107 MPGe combined | - | EPA 275 mi | - | 48995 | USD (MSRP excl. $1,295 destination) | US-built 2023 lineup with 62 kWh and 82 kWh batteries | https://insideevs.com/news/664846/2023-volkswagen-id4-epa-range-prices/ |
| 2024 | Pro / Pro S RWD (82 kWh) | 82 kWh | APP 550, 282 hp | RWD | - | - | EPA 291 mi | - | 44875 | USD (starting price of 82 kWh versions, excl. $1,425 destination) | APP 550 drive unit with more power, 12.9-inch infotainment screen on Pro, 20-inch wheels, ventilated front seats on S 82 kWh | https://insideevs.com/news/710357/2024-volkswagen-id4-prices/ |

---
※ 교육 실습용으로 공개된 수치를 재구성한 자료입니다. 실제 의사결정에 사용하지 마세요.